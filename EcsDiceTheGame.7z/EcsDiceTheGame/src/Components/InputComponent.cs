using System;

namespace ECS.Components
{

    public class InputComponent
    {
        public int Guess { get; set; }

    }
}



